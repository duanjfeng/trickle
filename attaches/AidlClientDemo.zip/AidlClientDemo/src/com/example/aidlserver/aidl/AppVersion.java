/**
 * 
 */
package com.example.aidlserver.aidl;

import android.os.Parcel;
import android.os.Parcelable;

public class AppVersion implements Parcelable {

    private String appPackage;
    private String versionCode;
    private String versionName;

    public AppVersion() {
        super();
    }

    public AppVersion(String appPackage, String versionCode, String versionName) {
        super();
        this.appPackage = appPackage;
        this.versionCode = versionCode;
        this.versionName = versionName;
    }

    // Must implements Parcelable.Creator<T>
    // Must named as CREATOR
    public static final Parcelable.Creator<AppVersion> CREATOR = new Creator<AppVersion>() {

                                                                   @Override
                                                                   public AppVersion createFromParcel(Parcel src) {
                                                                       // read orderly like writeToParcel
                                                                       AppVersion v = new AppVersion();
                                                                       v.setAppPackage(src.readString());
                                                                       v.setVersionCode(src.readString());
                                                                       v.setVersionName(src.readString());
                                                                       return v;
                                                                   }

                                                                   @Override
                                                                   public AppVersion[] newArray(int size) {
                                                                       return new AppVersion[size];
                                                                   }

                                                               };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        // write orderly like createFromParcel
        dest.writeString(appPackage);
        dest.writeString(versionCode);
        dest.writeString(versionName);
    }

    public String getAppPackage() {
        return appPackage;
    }

    public void setAppPackage(String appPackage) {
        this.appPackage = appPackage;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

}
