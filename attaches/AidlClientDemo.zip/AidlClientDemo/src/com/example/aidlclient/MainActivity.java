package com.example.aidlclient;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.example.aidlserver.aidl.AppVersion;
import com.example.aidlserver.aidl.IAppVersionService;

public class MainActivity extends Activity implements OnClickListener {

    // action name difined in server's AndroidManifest.xml
    private static final String ACTION_NAME       = "com.example.aidlserver.aidl.IAppVersionService";

    private static final String TAG               = "MainActivity";

    // Service instance
    private IAppVersionService  appVersionService = null;

    private Button              bindBtn;
    private Button              callBtn;
    private Button              unbindBtn;

    private ServiceConnection   connection        = new ServiceConnection() {

                                                      @Override
                                                      public void onServiceDisconnected(ComponentName arg0) {
                                                          Log.d(TAG, "onServiceDisconnected");
                                                          appVersionService = null;
                                                      }

                                                      @Override
                                                      public void onServiceConnected(ComponentName componentName,
                                                              IBinder binder) {
                                                          Log.d(TAG, "onServiceConnected");
                                                          appVersionService = IAppVersionService.Stub
                                                                  .asInterface(binder);

                                                          callBtn.setEnabled(true);
                                                          unbindBtn.setEnabled(true);
                                                      }
                                                  };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindBtn = (Button) findViewById(R.id.bindBtn);
        bindBtn.setOnClickListener(this);
        callBtn = (Button) findViewById(R.id.callBtn);
        callBtn.setOnClickListener(this);
        unbindBtn = (Button) findViewById(R.id.unbindBtn);
        unbindBtn.setOnClickListener(this);

        bindBtn.setEnabled(true);
        callBtn.setEnabled(false);
        unbindBtn.setEnabled(false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.bindBtn: {
            Log.d(TAG, "bind service");
            // Intent intent = new Intent(this.getApplicationContext(), IAppVersionService.class);
            Intent intent = new Intent(ACTION_NAME);
            // bindService will trigger onServiceConnected
            boolean bindResult = bindService(intent, connection, Context.BIND_AUTO_CREATE);
            Log.d(TAG, "bindResult: " + bindResult);
            bindBtn.setEnabled(false);
            callBtn.setEnabled(true);
            unbindBtn.setEnabled(true);
            break;
        }
        case R.id.callBtn: {
            Log.d(TAG, "call service");
            AppVersion latestVersion = null;
            try {
                // call service
                latestVersion = appVersionService.getLatestVersion("com.test");
            }
            catch (RemoteException e) {
                Log.e(TAG, "call service", e);
                e.printStackTrace();
            }
            if (latestVersion != null) {
                String text = "At client AppVersionService called: LastestVersion: " + latestVersion.getAppPackage()
                        + ";" + latestVersion.getVersionCode() + ";" + latestVersion.getVersionName();
                Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
                Log.d(TAG, text);
            }
            break;
        }
        case R.id.unbindBtn: {
            Log.d(TAG, "unbind service");
            unbindService(connection);
            bindBtn.setEnabled(true);
            callBtn.setEnabled(false);
            unbindBtn.setEnabled(false);
            break;
        }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
