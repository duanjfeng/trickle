package com.example;

import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import net.dongliu.apk.parser.ApkParser;
import net.dongliu.apk.parser.bean.ApkMeta;

import org.apache.commons.digester3.Digester;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.external.abx.Android_BX2;
import com.example.external.abx.GenXML;

public class ApkUtil {

	private final static Logger logger = LoggerFactory.getLogger(ApkUtil.class
			.getName());

	private static final String ANDROID_MANIFEST_XML = "AndroidManifest.xml";

	private static final Digester digester = new Digester();

	/**
	 * 解析apk中AndroidManifest.xml
	 */
	public static AndroidManifest parseAndroidManifestXmlByApkParser(File apk)
			throws Exception {

		AndroidManifest manifest = new AndroidManifest();
		ApkParser apkParser = null;
		try {
			apkParser = new ApkParser(apk);
			String xml = apkParser.getManifestXml();
			logger.debug("AndroidManifest.xml: {}", xml);
			ApkMeta apkMeta = apkParser.getApkMeta();
			manifest.setPackageName(apkMeta.getPackageName());
			manifest.setVersionCode(String.valueOf(apkMeta.getVersionCode()));
			manifest.setVersionName(apkMeta.getVersionName());
		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		} finally {
			if (apkParser != null) {
				apkParser.close();
				apkParser=null;
			}
		}
		return manifest;
	}

	/**
	 * 解析apk中AndroidManifest.xml
	 */
	public static AndroidManifest parseAndroidManifestXmlByBx2(File apk)
			throws Exception {

		String xml = transferAbx2Xml(apk);
		logger.debug("AndroidManifest.xml: {}", xml);
		AndroidManifest manifest = null;
		synchronized (digester) {
			manifest = (AndroidManifest) digester.parse(new StringReader(xml));
		}
		return manifest;
	}

	/**
	 * 将apk的AndroidManifest.xml（Android Binary XML格式）转换为标准XML格式字符串
	 */
	private static String transferAbx2Xml(File apk) throws Exception {

		InputStream is = null;
		ZipFile zipFile = new ZipFile(apk);
		String xml = "";
		try {
			Enumeration<? extends ZipEntry> entries = zipFile.entries();
			while (entries.hasMoreElements()) {
				ZipEntry entry = entries.nextElement();

				if (entry.getName().equals(ANDROID_MANIFEST_XML)) {
					is = zipFile.getInputStream(entry);
					break;
				}
			}
			Android_BX2 abx2 = new Android_BX2(new GenXML());
			xml = abx2.parse(is);

		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		} finally {
			try {
				if (zipFile != null)
					zipFile.close();
			} catch (Exception e) {
				// TODO: handle exception
				throw e;
			}
		}
		return xml;
	}
}
