package com.example.test;


import java.io.File;

import org.junit.Assert;
import org.junit.Test;

import com.example.AndroidManifest;
import com.example.ApkUtil;

public class ApkUtilTest {

	@Test
	public void testParseAndroidManifestXmlByApkParser() {
		try {
			AndroidManifest manifest = ApkUtil.parseAndroidManifestXmlByApkParser(getApkFile());
			Assert.assertNotNull(manifest);
			Assert.assertNotNull(manifest.getPackageName());
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	@Test
	public void testParseAndroidManifestXmlByBx2() {
		try {
			AndroidManifest manifest = ApkUtil.parseAndroidManifestXmlByBx2(getApkFile());
			Assert.assertNotNull(manifest);
			Assert.assertNotNull(manifest.getPackageName());
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	private File getApkFile(){
		File f = new File("./src/test/resources/example.apk");
		return f;
	}
}
