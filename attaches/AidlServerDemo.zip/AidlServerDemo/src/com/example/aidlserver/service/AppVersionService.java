package com.example.aidlserver.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.example.aidlserver.aidl.AppVersion;
import com.example.aidlserver.aidl.IAppVersionService;

public class AppVersionService extends Service {

    private static final String TAG = "AppVersionService";

    public class AppVersionServiceImpl extends IAppVersionService.Stub {

        @Override
        public AppVersion getLatestVersion(String appPackage) throws RemoteException {
            Log.d(TAG, "getLatestVersion");

            // Call server to get data
            AppVersion latestVersion = new AppVersion();
            latestVersion.setAppPackage("com.test");
            latestVersion.setVersionCode("21");
            latestVersion.setVersionName("2.1.0");

            String text = "At server AppVersionService: LastestVersion: " + latestVersion.getAppPackage() + ";"
                    + latestVersion.getVersionCode() + ";" + latestVersion.getVersionName();
            Log.d(TAG, text);

            return latestVersion;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind");
        IBinder binder = new AppVersionServiceImpl();
        return binder;
    }

}
